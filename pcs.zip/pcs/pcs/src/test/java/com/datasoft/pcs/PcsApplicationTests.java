package com.datasoft.pcs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcsApplicationTests {

	@Test
	void contextLoads() {
	}

}
