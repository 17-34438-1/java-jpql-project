package com.datasoft.pcs.Model.DTO;

public class UploadExcel {

    private String rtnValue;
    private String message;

    public String getRtnValue() {
        return rtnValue;
    }

    public void setRtnValue(String rtnValue) {
        this.rtnValue = rtnValue;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
