package com.datasoft.pcs.Model.DTO;

public class UpdateModel {
    private Long id;
    private String cont_status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCont_status() {
        return cont_status;
    }

    public void setCont_status(String cont_status) {
        this.cont_status = cont_status;
    }
}
