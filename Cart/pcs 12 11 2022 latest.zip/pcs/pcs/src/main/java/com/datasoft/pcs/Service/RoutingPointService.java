package com.datasoft.pcs.Service;


import com.datasoft.pcs.Model.sparcsn4.RefRoutingPoint;
import com.datasoft.pcs.Model.sparcsn4.RefUnlocCode;
import com.datasoft.pcs.Repository.sparcsn4.RefRoutingPointRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoutingPointService {
    @Autowired
    RefRoutingPointRepository refRoutingPointRepository;
    public List getRoutingPoint(){
        List<RefRoutingPoint> refRoutingPoints=new ArrayList<>();

        refRoutingPoints=refRoutingPointRepository.findAll();
        return refRoutingPoints;
    }


}
