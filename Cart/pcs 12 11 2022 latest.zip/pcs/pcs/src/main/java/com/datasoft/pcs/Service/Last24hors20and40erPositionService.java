package com.datasoft.pcs.Service;

public class Last24hors20and40erPositionService {
}
