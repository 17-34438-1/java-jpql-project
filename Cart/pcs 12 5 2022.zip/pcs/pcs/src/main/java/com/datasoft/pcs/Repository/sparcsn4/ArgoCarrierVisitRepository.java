package com.datasoft.pcs.Repository.sparcsn4;

public interface ArgoCarrierVisitRepository {
}
