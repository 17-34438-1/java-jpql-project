package com.datasoft.pcs.Controller;
import com.datasoft.pcs.Service.IgmCommudityService;
import com.datasoft.pcs.Service.IgmOffdockInformationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value="/IgmOpetation")
public class IgmOperationController {
    @Autowired
    IgmCommudityService igmCommudityService;

    @Autowired
    IgmOffdockInformationService igmOffdockInformationService;

    @RequestMapping(value = "/IgmOpetation/CommudityList", method= RequestMethod.GET)
    @ResponseBody
    public List getIgmCommudityList()  {
        List list =new ArrayList<>();
        list=igmCommudityService.getIgmCommudity();
        return list;
    }

    @RequestMapping(value = "/IgmOpetation/OffDockInformation", method= RequestMethod.GET)
    @ResponseBody
    public List getIgmOffDockInfoList()  {
        List list =new ArrayList<>();
        list=igmOffdockInformationService.myoffDociew();
        return list;
    }


}
