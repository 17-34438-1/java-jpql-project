package com.datasoft.pcs.Service;
import com.datasoft.pcs.Model.cchaportdb.SadContainer;
import com.datasoft.pcs.Repository.cchaportdb.SadContainerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class SadContainerService {
    @Autowired
    SadContainerRepository sadContainerRepository;
    public List getSadContainer(String entryDate)  {
        System.out.println(entryDate);
        List<SadContainer>  result = sadContainerRepository.findByContNumber(entryDate);
        return result;
    }
}
