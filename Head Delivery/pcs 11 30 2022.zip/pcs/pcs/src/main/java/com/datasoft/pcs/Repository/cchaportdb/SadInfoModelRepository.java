package com.datasoft.pcs.Repository.cchaportdb;


import com.datasoft.pcs.Model.cchaportdb.SadInfoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SadInfoModelRepository extends JpaRepository<SadInfoModel,Integer> {
//    List<SadInfoModel> findByEntryDateContains(String entryDate);
//    List<SadInfoModel> countByIpAddress(String entryDate);

//    @Query(value = "SELECT sad.ipAddress,sad.entryDate\n" +
//            "FROM SadInfoModel sad\n" +
//            "WHERE entryDate=:entryDate\n" +
//            "GROUP BY ipAddress")



    @Query(value = "SELECT COUNT(*) AS tot_entry,igms.ipAddress,igms.entryDate\n" +
            "FROM SadInfoModel igms\n" +
            "WHERE DATE(igms.entryDate)=:EntryDate\n" +
            "GROUP BY igms.ipAddress")
  List<SadInfoModel> urlListByModule(@Param("EntryDate") String EntryDate);



//    Integer isRoleIdExists(@Param("entryDate") String entryDate);

//    @Query(value = "SELECT COUNT(*) FROM cchaportdb.organization_profiles_test WHERE id=:org_id")
//    Integer isOrganizationExists(@Param("org_id") Integer org_id);

}
