package com.datasoft.pcs.Service;
import com.datasoft.pcs.Model.DTO.BillofEntryListDtoModel;
import com.datasoft.pcs.Model.cchaportdb.SadInfoModel;

import com.datasoft.pcs.Repository.cchaportdb.SadInfoModelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


import javax.persistence.EntityManagerFactory;
import java.util.ArrayList;
import java.util.List;
@Service
public class SadContainerService {
    @Autowired
    SadInfoModelRepository sadInfoModelRepository;


    @Autowired
    @Qualifier("cchaportdbEntityManagerFactory")
    EntityManagerFactory entityManagerFactory;


    public List getSadContainer(String entryDate)  {
        List<SadInfoModel>  result=new ArrayList<>();
//        EntityManager entitymanager= entityManagerFactory.createEntityManager();
//        String mainQuery="";
//
////        mainQuery="SELECT new com.datasoft.pcs.Model.DTO.BillofEntryListDtoModel(igms.,igms.igmId) FROM  SadInfoModel igms \n" +
////                "WHERE igms.igmId='"+entryDate+"'";

//        mainQuery="SELECT new com.datasoft.pcs.Model.DTO.BillofEntryListDtoModel(igms.ipAddress,igms.entryDate)\n" +
//                "FROM SadInfoModel igms\n" +
//                "WHERE DATE(entry_dt)='"+entryDate+"'\n" +
//                "GROUP BY ip_address \n";

//        System.out.println("mainQuery:"+mainQuery);
//        result =entitymanager.createQuery(mainQuery).getResultList();



        result=sadInfoModelRepository.findByEntryDateContains(entryDate);
        System.out.println("result:"+result.size());

        Integer m=0;
        int i=0;
        while (i< result.size()){
            BillofEntryListDtoModel resultModel=new BillofEntryListDtoModel();

            String ipAddress;
            ipAddress=result.get(i).getIpAddress();
            System.out.println("ipAddress:"+ipAddress);
            System.out.println("ipAddress:"+ipAddress.length());
            resultModel.setIp_address(ipAddress);
            i++;
        }

        return result;
    }
}
