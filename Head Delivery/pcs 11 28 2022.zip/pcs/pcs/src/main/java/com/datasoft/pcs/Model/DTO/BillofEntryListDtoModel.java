package com.datasoft.pcs.Model.DTO;

public class BillofEntryListDtoModel {
    private Integer CountIp;
    private String ip_address;
    private String entry_dt;



    public String getIp_address() {
        return ip_address;
    }

    public void setIp_address(String ip_address) {
        this.ip_address = ip_address;
    }

    public String getEntry_dt() {
        return entry_dt;
    }

    public void setEntry_dt(String entry_dt) {
        this.entry_dt = entry_dt;
    }
}
