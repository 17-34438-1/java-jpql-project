package com.datasoft.pcs.Repository.cchaportdb;

import com.datasoft.pcs.Model.cchaportdb.IgmCorrectionLog;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IgmCorrectionLogRepository extends JpaRepository<IgmCorrectionLog,Integer> {

}