package com.datasoft.pcs.Model.cchaportdb;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter
@Table(name="igm_correction_log_copy")
public class IgmCorrectionLog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;


    @Column(name="ref_tbl_id")
    public Integer refTblId;

    @Column(name = "change_type")
    public String changeType;
    @Column(name = "igm_type")
    public String igmType;
    @Column(name = "prior_value")
    public String priorValue;
    @Column(name = "new_value")
    public String newValue;

    @Column(name = "entry_by")
    public String entryBy;
    @Column(name ="entry_at")
    public String entry_at;
    @Column(name="entry_ip")
    public String entry_ip;

}
