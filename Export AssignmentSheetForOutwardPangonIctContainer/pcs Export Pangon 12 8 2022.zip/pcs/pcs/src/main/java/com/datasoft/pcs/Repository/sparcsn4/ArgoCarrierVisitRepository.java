package com.datasoft.pcs.Repository.sparcsn4;

import com.datasoft.pcs.Model.sparcsn4.ArgoCarrierVisit;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ArgoCarrierVisitRepository extends JpaRepository<ArgoCarrierVisit,Integer> {
}
