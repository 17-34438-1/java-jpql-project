package com.datasoft.pcs.Repository.cchaportdb;

import com.datasoft.pcs.Model.cchaportdb.EdoApplicationByCf;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EdoApplicationByCfRepository extends JpaRepository<EdoApplicationByCf,Integer> {

}